package com.example.gibbiez.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.gibbiez.network.RetrofitClient
import com.example.gibbiez.network.models.NutritionRequest
import com.example.gibbiez.network.models.NutritionResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NutritionViewModel : ViewModel() {
    private val _nutritionResult = MutableLiveData<String>()
    val nutritionResult: LiveData<String> get() = _nutritionResult

    fun calculateNutrition(request: NutritionRequest) {
        RetrofitClient.nutritionService.predictNutrition(request)
            .enqueue(object : Callback<NutritionResponse> {
                override fun onResponse(
                    call: Call<NutritionResponse>, response: Response<NutritionResponse>
                ) {
                    if (response.isSuccessful) {
                        _nutritionResult.value = response.body()?.result ?: "No result"
                    } else {
                        _nutritionResult.value = "Failed to calculate"
                    }
                }

                override fun onFailure(call: Call<NutritionResponse>, t: Throwable) {
                    _nutritionResult.value = "Error: ${t.message}"
                }
            })
    }
}
