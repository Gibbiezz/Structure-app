package com.example.gibbiez

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.gibbiez.databinding.FragmentOnboarding1Binding

class Onboarding1Fragment : Fragment() {
    private lateinit var binding: FragmentOnboarding1Binding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentOnboarding1Binding.inflate(inflater, container, false)

        binding.btnSkip.setOnClickListener {
            Toast.makeText(context, "Skip to Home", Toast.LENGTH_SHORT).show()
        }

        binding.btnNext.setOnClickListener {
            Toast.makeText(context, "Next Onboarding", Toast.LENGTH_SHORT).show()
        }

        return binding.root
    }
}
