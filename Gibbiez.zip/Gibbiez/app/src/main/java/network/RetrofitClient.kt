package com.example.gibbiez.network

import network.ApiService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private const val BASE_URL_NUTRITION = "http://34.128.75.155:5000/"
    private const val BASE_URL_IMAGE = "http://34.50.70.8:5000/"

    val nutritionService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL_NUTRITION)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    val imageService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL_IMAGE)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

