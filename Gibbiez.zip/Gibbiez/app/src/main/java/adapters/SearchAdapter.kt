package com.example.gibbiez.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.gibbiez.databinding.ItemSearchBinding

class SearchAdapter(private val originalData: List<String>) :
    RecyclerView.Adapter<SearchAdapter.ViewHolder>() {

    private var filteredData: List<String> = originalData

    class ViewHolder(val binding: ItemSearchBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSearchBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.searchResult.text = filteredData[position]
    }

    override fun getItemCount(): Int = filteredData.size

    fun filter(query: String) {
        filteredData = if (query.isEmpty()) {
            originalData
        } else {
            originalData.filter { it.contains(query, ignoreCase = true) }
        }
        notifyDataSetChanged()
    }
}
