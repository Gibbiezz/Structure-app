package com.example.gibbiez

import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.gibbiez.network.RetrofitClient
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.await
import java.io.File

class CameraFragment : Fragment(R.layout.fragment_camera) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        captureImage { uri ->
            uploadImageToApi(uri)
        }
    }

    private fun captureImage(onImageCaptured: (Uri) -> Unit) {

    }

    private fun uploadImageToApi(imageUri: Uri) {
        val file = File(imageUri.path!!)
        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), file)
        val body = MultipartBody.Part.createFormData("image", file.name, requestFile)

        lifecycleScope.launchWhenCreated {
            try {
                val response = RetrofitClient.imageService.uploadImage(body).await()

                println("Hasil: ${response.result}")
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
