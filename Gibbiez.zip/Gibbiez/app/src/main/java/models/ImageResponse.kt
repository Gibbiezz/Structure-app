package com.example.gibbiez

data class ImageResponse(
    val status: String,
    val message: String,
    val prediction: String,
    val recipe: String      // Contoh rekomendasi resep makanan
)
