package com.example.gibbiez

data class NutritionRequest(
    val Umur: Int,
    val `Jenis Kelamin`: String,
    val `Tinggi Badan`: Float
)
