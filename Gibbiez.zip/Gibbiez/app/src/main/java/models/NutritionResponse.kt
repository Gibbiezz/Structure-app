package com.example.gibbiez

data class NutritionResponse(
    val status: String,
    val message: String,
    val result: String // Contoh hasil: "Gizi Baik", "Gizi Kurang", dll
)
